# Shadow Selfbot
## Most demanded selfbot on cord 

**Shadow Selfbot Comes with 185+ commands and 22 categories:**

```
> System
> Utility
> Emoji
> Moderation
> Security
> Snipe
> Nuke
> Fun
> Nsfw
> Text
> Vouch
> Auto Responder
> Crypto
> Guild
> Checker
> LTC Sender
> Selling
> Status
> VC
> Usercmds
> music
> autosender
```
<details>
	<summary>Click to expand</summary>
https://imgur.com/a/rYu3Unt
</details>
---

# ***Usage:***

### **Join my Discord Server For Emojis**  
[Click here to join!](https://discord.gg/n8MUXvsz4V)

### **Host on Render**  
[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy)

### **1. Open the `config.json` file.**

### **2. Configure the following settings:**

- **`"token"`**  
  Replace `your-user-token` with your Discord Token

- **`"prefix"`**  
  Set your desired prefix (default is `">"`).  

- **`"bot_name"`**  
  Customize the name for your bot (e.g., `"Shadow Selfbot"`).  

- **`"User_Id"`**  
  Replace with your (Discord User ID).  

- **`"SERVER_Link"`**  
  Provide your Discord server invite link.  

- **`"BLOCKCYPHER_API_TOKEN"`**  
  Add your API token if you're using cryptocurrency functionalities (optional).  

- **`"LTC_ADDRESS"`**  
  Input your Litecoin (LTC) address for receiving transactions.  

- **`"LTC_PRIVATE_KEY"`**  
  Add your private key for Litecoin wallet management (use cautiously).  

- **`"UPI_ID"`**  
  Update this field with your UPI ID if you're using UPI for payments.  

- **`"non_nito_alt"`**  
  Replace `non_nitro_alt_token` with an alternate Discord token.  

- **`"webhook"`**  
  Replace `your-webhooklink` with your logging webhook URL.


**Tips:**
- **Keep your configuration file secure**—leaking sensitive data like tokens, private keys, or API keys may compromise your account or bot.  
- **Using selfbots violates Discord's Terms of Service.** Use responsibly and at your own risk.  

**Contact:** `server.py(955721842675560462)`  

> **To use VC-Commands you must download wavelink
